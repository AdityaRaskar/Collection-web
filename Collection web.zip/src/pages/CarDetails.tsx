import React from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useCar } from '../hooks/useCar'
import { deleteCar } from '../services/cars'
import ImageGallery from '../components/ImageGallery'
import { useAuth } from '../hooks/useAuth'

export default function CarDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { carQuery, imagesQuery } = useCar(id)
  const { user } = useAuth()

  const car = carQuery.data

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">{car?.name ?? 'Car Details'}</h2>
        {user ? (
          <div className="space-x-2">
            <button className="px-3 py-1 border rounded" onClick={() => navigate(`/admin/edit-car/${id}`)}>
              Edit
            </button>
            <button
              className="px-3 py-1 border rounded text-red-600"
              onClick={async () => {
                if (!confirm('Delete this car? This action cannot be undone.')) return
                try {
                  await deleteCar(id as string)
                  navigate('/')
                } catch (err) {
                  alert('Failed to delete car')
                }
              }}
            >
              Delete
            </button>
          </div>
        ) : null}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {imagesQuery.isLoading ? (
            <div className="h-64 bg-gray-100 animate-pulse" />
          ) : (
            <ImageGallery images={(imagesQuery.data ?? []) as any} />
          )}
        </div>
        <div className="bg-white dark:bg-gray-800 rounded p-4 shadow">
          <dl>
            <div>
              <dt className="text-sm text-gray-500">Brand</dt>
              <dd className="mb-2">{car?.brand ?? '—'}</dd>
            </div>
            <div>
              <dt className="text-sm text-gray-500">Series</dt>
              <dd className="mb-2">{car?.series ?? '—'}</dd>
            </div>
            {car?.year && (
              <div>
                <dt className="text-sm text-gray-500">Year</dt>
                <dd className="mb-2">{car.year}</dd>
              </div>
            )}
            {car?.model_number && (
              <div>
                <dt className="text-sm text-gray-500">Model #</dt>
                <dd className="mb-2">{car.model_number}</dd>
              </div>
            )}
            {car?.purchase_price != null && (
              <div>
                <dt className="text-sm text-gray-500">Purchase Price</dt>
                <dd className="mb-2">${car.purchase_price}</dd>
              </div>
            )}
            {car?.description && (
              <div>
                <dt className="text-sm text-gray-500">Description</dt>
                <dd className="mb-2">{car.description}</dd>
              </div>
            )}
          </dl>
        </div>
      </div>
    </div>
  )
}
