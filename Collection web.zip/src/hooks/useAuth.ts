import { useEffect, useState, useCallback } from 'react'
import supabase from '../services/supabase'

export function useAuth() {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const init = async () => {
      const { data } = await supabase.auth.getSession()
      setUser((data as any)?.session?.user ?? null)
    }
    init()

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser((session as any)?.user ?? null)
    })

    return () => listener?.subscription.unsubscribe()
  }, [])

  const signIn = useCallback(async (email: string, password: string) => {
    const res = await supabase.auth.signInWithPassword({ email, password })
    // log full response for debugging
    // eslint-disable-next-line no-console
    console.debug('signIn result', res)
    const { error } = res
    if (error) {
      // eslint-disable-next-line no-console
      console.error('Sign in error', error)
      throw error
    }
    return true
  }, [])

  const signOut = useCallback(async () => {
    await supabase.auth.signOut()
    setUser(null)
  }, [])

  return { user, signIn, signOut }
}
