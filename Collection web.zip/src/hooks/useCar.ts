import { useQuery } from '@tanstack/react-query'
import { fetchCarById, fetchImagesForCar } from '../services/cars'

export function useCar(id?: string) {
  const carQuery = useQuery({
    queryKey: ['car', id],
    queryFn: () => fetchCarById(id as string),
    enabled: !!id
  })

  const imagesQuery = useQuery({
    queryKey: ['car', id, 'images'],
    queryFn: () => fetchImagesForCar(id as string),
    enabled: !!id
  })

  return { carQuery, imagesQuery }
}
