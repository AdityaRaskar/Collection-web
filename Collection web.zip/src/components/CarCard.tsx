import React from 'react'
import { Car } from '../types'
import { Link } from 'react-router-dom'

type Props = {
  car?: Partial<Car>
}

export default function CarCard({ car }: Props) {
  return (
    <article className="bg-white dark:bg-gray-800 rounded shadow p-4">
      <Link to={car?.id ? `/car/${car.id}` : '#'} className="block">
        <div className="h-40 bg-gray-200 dark:bg-gray-700 rounded mb-3 flex items-center justify-center">
          {car?.extra_attributes?.thumbnail ? (
              <img src={car.extra_attributes.thumbnail} alt={car.name} className="object-cover h-full w-full rounded" loading="lazy" />
            ) : (
            <span className="text-gray-500">No image</span>
          )}
        </div>
        <h3 className="font-semibold">{car?.name ?? 'Untitled'}</h3>
        <div className="text-sm text-gray-500">{[car?.brand, car?.series, car?.year].filter(Boolean).join(' • ')}</div>
      </Link>
    </article>
  )
}
