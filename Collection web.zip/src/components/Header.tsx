import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'

export default function Header() {
  const { user } = useAuth()
  const [dark, setDark] = useState<boolean>(() => document.documentElement.classList.contains('dark'))

  useEffect(() => {
    if (dark) document.documentElement.classList.add('dark')
    else document.documentElement.classList.remove('dark')
  }, [dark])

  return (
    <header className="bg-white dark:bg-gray-800 shadow">
      <div className="container mx-auto p-4 flex items-center justify-between">
        <Link to="/" className="font-bold text-lg">
          HotWheels Collection
        </Link>
        <nav className="flex items-center gap-4">
          <Link to="/" className="text-sm text-gray-600 dark:text-gray-300">
            Collection
          </Link>
          {user && (
            <Link to="/admin/add-car" className="text-sm text-blue-600">
              + Add New Car
            </Link>
          )}
          <Link to="/login" className="text-sm text-gray-600">
            {user ? 'Account' : 'Admin'}
          </Link>
          <button
            onClick={() => setDark((d) => !d)}
            aria-label="Toggle dark mode"
            className="px-2 py-1 border rounded text-sm"
          >
            {dark ? 'Light' : 'Dark'}
          </button>
        </nav>
      </div>
    </header>
  )
}
