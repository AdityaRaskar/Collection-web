import React, { useEffect, useState } from 'react'
import supabase from '../services/supabase'

type Props = {
  images: Array<{ id: string; image_url: string; image_path?: string }>
}

export default function ImageGallery({ images }: Props) {
  const [urls, setUrls] = useState<Record<string, string>>({})

  useEffect(() => {
    let mounted = true
    async function resolve() {
      const map: Record<string, string> = {}
      for (const img of images || []) {
        if (img.image_path) {
          // try public URL first
          try {
            const pub = supabase.storage.from('car-images').getPublicUrl(img.image_path)
            const publicUrl = (pub as any)?.data?.publicUrl ?? ''
            if (publicUrl) {
              map[img.id] = publicUrl
              continue
            }
          } catch (_) {
            // ignore
          }

          // fall back to signed URL
          try {
            const signed = await supabase.storage.from('car-images').createSignedUrl(img.image_path, 60 * 60)
            map[img.id] = (signed as any)?.data?.signedUrl ?? img.image_url
            continue
          } catch (_) {
            map[img.id] = img.image_url
            continue
          }
        }

        // default to whatever is stored
        map[img.id] = img.image_url
      }
      if (mounted) setUrls(map)
    }
    resolve()
    return () => {
      mounted = false
    }
  }, [images])

  if (!images || images.length === 0) {
    return (
      <div className="h-64 bg-gray-100 dark:bg-gray-800 rounded flex items-center justify-center">
        <div className="text-gray-500">No images</div>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      <div className="rounded overflow-hidden">
        <img src={urls[images[0].id] ?? images[0].image_url} alt="Main" className="w-full h-64 object-cover rounded" loading="lazy" />
      </div>
      <div className="flex gap-2 overflow-x-auto">
        {images.map((img) => (
          <img key={img.id} src={urls[img.id] ?? img.image_url} alt="thumb" className="w-20 h-20 object-cover rounded" loading="lazy" />
        ))}
      </div>
    </div>
  )
}
